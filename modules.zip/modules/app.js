/**
 * Created by danielscott on 3/7/17.
 */
let math = require('./mathlib');

console.log(math().add(1, 9));
console.log(math().multiply(66, 9));
console.log(math().square(5));
console.log(math().randomNum(1, 3));
