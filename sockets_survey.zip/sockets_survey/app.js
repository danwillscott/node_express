/**
 * Created by Daniel Scott on 3/8/17.
 */
// require express and path
let express = require("express");
let path = require("path");
// create the express app
let app = express();
// static content
app.use(express.static(path.join(__dirname, "./static")));
// setting up ejs and our views folder
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
// root route to render the index.ejs view
app.get('/', function(req, res) {
    res.render("index");
});

// this selects our port and listens
// note that we're now storing our app.listen within
// a variable called server. this is important!!

let server = app.listen(8000, function() {
    console.log("listening on port 8000");
});
// this is a new line we're adding AFTER our server listener
// take special note how we're passing the server
// variable. unless we have the server variable, this line will not work!!
let io = require('socket.io').listen(server);

// Whenever a connection event happens (the connection event is built in) run the following code
io.sockets.on('connection', function (socket) {
    console.log("WE ARE USING SOCKETS!");
    // console.log(socket.id);
    //all the socket code goes in here!
    socket.on("form_submit", function (data){
        console.log('Someone clicked a button!  Reason: ' + data.form_data);
        socket.emit('return_form', {response: data.form_data});
    })
});
