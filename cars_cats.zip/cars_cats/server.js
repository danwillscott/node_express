/**
 * Created by danielscott on 3/7/17.
 */
// port
let port = 7077;
// get http module
let http = require('http');
// file system
let fs = require('fs');
// server
let server = http.createServer(function (request, response) {
    console.log('in side server requesting...', request.url);

    //routing
    function this_route(location, content_type) {
        if(content_type === 'text/html'){
            fs.readFile(location, 'utf8', function (errors, contents) {
                response.writeHead(200, {'Content-Type': 'text/html'});  // send data about response
                response.write(contents);  //  send response body
                response.end(); // finished!

            });
        } else if (content_type === 'image/png'){
            fs.readFile(location, function (errors, contents) {
                response.writeHead(200, {'Content-Type': content_type});  // send data about response
                response.write(contents);  //  send response body
                response.end(); // finished!

            });
        } else if (content_type === 'text/css'){
            fs.readFile(location, 'utf8', function (errors, contents) {
                response.writeHead(200, {'Content-Type': content_type});  // send data about response
                response.write(contents);  //  send response body
                response.end(); // finished!

            });
        }
    }

    // URLS
    if (request.url === '/'){
        this_route('index.html', 'text/html');
    } else if(request.url === '/cars'){
        this_route('car.html', 'text/html');

    } else if (request.url === '/cats'){
        this_route('cat.html' , 'text/html');

    } else if (request.url === '/cars/new') {
        this_route('new_car.html', 'text/html');
    }
    // Images
    else if (request.url === '/images/phone1'){
        this_route('images/phone1.png', 'image/png');
    }

    // Styles
    else if(request.url === '/styles/style'){
        this_route('styles/style.css', 'text/css');
    } else if (request.url === '/scripts/script'){
        this_route('scripts/script.js', 'text/javascript');
    }


    // If Not Found
    else {
        response.writeHead(404);
        response.end('File not found!!!');
    }



});

server.listen(port);

console.log("simple node server running on port ", port);